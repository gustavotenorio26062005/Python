nome = input('Qual seu nome? \n')
print('Olá, ' + nome)

dia = input('Qual dia você nasceu? \n')
mes = input('Qual mês você nasceu? \n')
ano = input('Qual ano você nasceu? \n')

print(nome+' Sua data de nascimento é: '+ dia + '/'+ mes + '/'+ ano + '/')

num1 = int(input('Digite um número: '))
num2 = int(input('Digite outro número: '))

print('A soma deles é: ',num1+num2)

digitar = input('Digite algo: ')
tipo = type(digitar)